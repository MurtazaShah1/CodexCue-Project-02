class URLShortener:
    def __init__(self):
        self.url_dict = {}
        self.id = 0
        self.base_url = "http://short.url/"
        self.chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

    def _encode(self, num):
        if num == 0:
            return self.chars[0]
        encoded = []
        while num > 0:
            encoded.append(self.chars[num % 62])
            num //= 62
        return ''.join(encoded[::-1])

    def shorten_url(self, long_url):
        if not long_url.strip():
            return "Error: The URL is empty!"
        self.id += 1
        short_key = self._encode(self.id)
        short_url = self.base_url + short_key
        self.url_dict[short_url] = long_url
        return short_url

    def retrieve_url(self, short_url):
        if not short_url.startswith(self.base_url):
            return "Error: Invalid short URL!"
        return self.url_dict.get(short_url, "URL not found!")

    def display_mappings(self):
        if not self.url_dict:
            print("No URL mappings found.")
        else:
            for short, long in self.url_dict.items():
                print(f"{short} -> {long}")

def main():
    url_shortener = URLShortener()

    while True:
        print("URL Shortener")
        print("1. Shorten a URL")
        print("2. Retrieve a URL")
        print("3. Display all URL mappings")
        print("4. Exit")

        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            long_url = input("Enter the long URL to shorten: ")
            short_url = url_shortener.shorten_url(long_url)
            print(f"Short URL: {short_url}")

        elif choice == '2':
            short_url = input("Enter the short URL to retrieve: ")
            retrieved_url = url_shortener.retrieve_url(short_url)
            print(f"Retrieved URL: {retrieved_url}")

        elif choice == '3':
            url_shortener.display_mappings()

        elif choice == '4':
            print("Exiting...")
            break

        else:
            print("Invalid choice, please select a valid option.")

if __name__ == "__main__":
    main()
